# Transform structure to 3Di\_v3 states (CPP version)

    git submodule update
    make test
