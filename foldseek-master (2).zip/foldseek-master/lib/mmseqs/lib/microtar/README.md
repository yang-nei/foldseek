# microtar
A lightweight tar library written in ANSI C

This library was adapted from the original microtar (https://github.com/rxi/microtar) 
to be read-only and support fast seeking.

## License
This library is free software; you can redistribute it and/or modify it under
the terms of the MIT license. See [LICENSE](LICENSE) for details.
