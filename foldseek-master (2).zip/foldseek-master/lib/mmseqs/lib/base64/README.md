NibbleAndAHalf
==============

"Nibble And A Half" is an ANSI C library that provides fast base64 encoding and decoding, all in a single header file.

Wed Apr 17 6:13p
- All test related functions moved to testbase64.h.  To use, only need #include "base64.h":
  https://github.com/superwills/NibbleAndAHalf/blob/master/NibbleAndAHalf/base64.h
